#pragma fastcall16 StartFreq
extern void  StartFreq(void);

